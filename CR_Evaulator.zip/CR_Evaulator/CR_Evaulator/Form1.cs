﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CR_Evaulator
{
    public partial class Form1 : Form
    {
        string parentDirectory = @"C:\H_Drive\WorkSpace\Crystal Reports\GB04SQLiScala\";
        Utility objUtility = new Utility();
        ObservableCollection<Info> lstInfo = new ObservableCollection<Info>();
        int counter = 0;

        public Form1()
        {
            InitializeComponent();
            lstInfo.CollectionChanged += LstInfo_CollectionChanged;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = parentDirectory;
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            folderBrowserDialog1.SelectedPath = parentDirectory = textBox1.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                parentDirectory = textBox1.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            objUtility.ShowAllFolders(parentDirectory, lstInfo);
            MessageBox.Show("Job Completed!");
        }

        private void LstInfo_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            counter++;

            // Now that DataGridView has calculated it's Widths; we can now store each column Width values.
            for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
            {
                // Store Auto Sized Widths:
                int colw = dataGridView1.Columns[i].Width;

                // Remove AutoSizing:
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.None;

                // Set Width to calculated AutoSize value:
                dataGridView1.Columns[i].Width = colw;
            }

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = lstInfo;
            dataGridView1.Invalidate();

            // Set your desired AutoSize Mode:
            dataGridView1.Columns[0].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[1].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            dataGridView1.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

            dataGridView1.FirstDisplayedScrollingRowIndex = dataGridView1.RowCount - 1;


            if (counter % 10 == 0)
            {
                Application.DoEvents();
            }
        }

       
    }
}
