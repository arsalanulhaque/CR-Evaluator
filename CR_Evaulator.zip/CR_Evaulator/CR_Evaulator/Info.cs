﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CR_Evaulator
{
    class Info
    {
        public string Folder { get; set; }
        public int TotalFiles { get; set; }
        public string FileName { get; set; }
        public string SubReportName { get; set; }
        public bool isSQLConnection { get; set; }

    }
}
