﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CR_Evaulator
{
    class Utility
    {
        private ObservableCollection<Info> _lstInfo = null;

        public void ShowAllFolders(string path, ObservableCollection<Info> lstInfo)
        {
            try
            {
                _lstInfo = lstInfo;

                Info objInfo = new Info();
                objInfo.Folder = path;
                objInfo.TotalFiles = GetTotalFiles(path);
                _lstInfo.Add(objInfo);

                GetFiles(path);

                if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != FileAttributes.ReparsePoint)
                {
                    foreach (string folder in Directory.GetDirectories(path))
                    {
                        ShowAllFolders(folder, _lstInfo);
                    }
                }
            }
            catch (UnauthorizedAccessException) { }
        }

        private void GetFiles(string path)
        {

            DirectoryInfo d = new DirectoryInfo(path); //Assuming Test is your Folder
            FileInfo[] Files = d.GetFiles("*.rpt"); //Getting Text files


            foreach (FileInfo file in Files)
            {
                Info objInfo = new Info();
                objInfo.Folder = path;
                objInfo.FileName = file.Name;
                objInfo.SubReportName = subReportPath(file.FullName);
                _lstInfo.Add(objInfo);
            }
        }

        private string subReportPath(string path)
        {
            string strName = "";
            ReportDocument subReport = null;
            try
            {
                ReportDocument cryRpt = new ReportDocument();
                cryRpt.Load(path);

                //Where report is the parent rpt of type ReportDocument (or a subclass of ReportDocument)
                for (int i = 0; i < cryRpt.Subreports.Count; i++)
                {
                    subReport = cryRpt.Subreports[i];
                    if (subReport != null)
                    {
                        strName += subReport.Name + ",";
                    }
                }

                cryRpt.Dispose();
                cryRpt.Close();
                cryRpt.Dispose();
                cryRpt.Close();
                strName = (strName.Length > 2 ? strName.Substring(0, strName.Length - 1) : "NA");
            }
            catch (Exception ex)
            {
                strName = "Error: " + (subReport != null ? subReport.Name : "") + " " + ex.Message + Environment.NewLine + ex.InnerException;
            }
            return strName;
        }


        private int GetTotalFiles(string path)
        {
            string[] reportFiles = Directory.GetFiles(path, "*.rpt", SearchOption.TopDirectoryOnly);
            return reportFiles.Length;
        }
    }
}